import { combineReducers } from "@reduxjs/toolkit";
import report from "./report";

export default combineReducers({ report });
